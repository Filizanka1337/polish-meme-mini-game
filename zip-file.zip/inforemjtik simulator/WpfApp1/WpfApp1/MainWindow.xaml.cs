﻿using System;
using System.Windows;
using System.Diagnostics;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string loginValue = login.Text;
            string passwordValue = password.Text;

            if (loginValue == "informejtik" && passwordValue == "2137")
            {
                // Otwieramy stronę internetową po prawidłowym zalogowaniu.
                Process.Start("microsoft-edge:", "https://www.youtube.com/watch?v=dVgXNlJ2o7g");
            }
            else
            {
                // Wyświetlamy MessageBox z komunikatem "password incorrect" po nieprawidłowym zalogowaniu.
                MessageBox.Show("Password incorrect");
            }
        }
    }
}
